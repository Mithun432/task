let list=[
        {
        name:"Kiran",
        mark:98
        },
        {
        name:"Athul",
        mark:90
        },
        {
        name:"John", 
        mark:100
        },
        {
        name:"Cathy", 
        mark:76
        },
        {
        name:"Yamuna", 
        mark:84
        },
        {
        name:"Vishnupriya",
        mark:79
        }
        ];
    buidtable(list);
function buidtable(datas)
{
    var table=document.getElementById('mytable');
    for(let i=0; i <list.length;i++)
    {
       var row = '<tr>
        <td>${datas[i].name}</td>
        <td>${datas[i].mark}</td>
        </tr>';
            table.innerHTML+=row;
    }
}